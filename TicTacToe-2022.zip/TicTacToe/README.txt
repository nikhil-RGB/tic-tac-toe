1)Please ensure you have JAVA 8(1.8) installed on your system, as it will be required to run the application
2)To play this game, double tap on the .exe application file in this folder.
3)If you enjoy playing my games, you can check out more of my work from:
https://www.swingguiking.com/my-work
4)If you have problems with launching the .exe, you can always just launch the JAR file named Cross n Knots